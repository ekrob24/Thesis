
import pandas as pd

class SaveResultsBitcoin:
    def __init__(self, predicted_prices, actual_prices):
        self.predicted_prices = predicted_prices
        self.actual_prices = actual_prices

    def save_to_csv(self, filename):
        results_df = pd.DataFrame({
            'Actual': self.actual_prices.flatten(),
            'Predicted': self.predicted_prices.flatten()
        })
        results_df.to_csv(filename, index=False)
