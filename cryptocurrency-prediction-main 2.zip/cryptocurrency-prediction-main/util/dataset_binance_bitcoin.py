
import requests
import pandas as pd

class BinanceBitcoinDataset:
    def __init__(self, symbol="BTCUSDT", interval="1d"):
        self.symbol = symbol
        self.interval = interval
        self.df = self.load_data()

    def load_data(self):
        url = f'https://api.binance.com/api/v3/klines?symbol={self.symbol}&interval={self.interval}'
        response = requests.get(url)
        data = response.json()
        
        # DataFrame construction for Bitcoin's OHLC data
        df = pd.DataFrame(data, columns=['timestamp', 'Open', 'High', 'Low', 'Close', 'Volume', 'Close_time', 
                                         'Quote_asset_volume', 'Number_of_trades', 'Taker_buy_base_asset_volume', 
                                         'Taker_buy_quote_asset_volume', 'Ignore'])
        df['Date'] = pd.to_datetime(df['timestamp'], unit='ms')
        df['Close'] = df['Close'].astype(float)
        df = df[['Date', 'Close']]  # Focus on date and closing price
        return df
