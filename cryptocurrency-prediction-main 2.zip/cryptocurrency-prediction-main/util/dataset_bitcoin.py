
import pandas as pd

class BitcoinDataset:
    def __init__(self, filepath):
        self.filepath = filepath
        self.df = self.load_data()

    def load_data(self):
        df = pd.read_csv(self.filepath, parse_dates=['Date'])
        df = df.sort_values('Date')
        return df

    def get_close_prices(self):
        return self.df[['Close']]  # Only return Bitcoin closing prices
