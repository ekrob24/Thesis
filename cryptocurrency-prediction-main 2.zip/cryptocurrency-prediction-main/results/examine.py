import os
import pandas as pd

def ensure_dir_exists(dir_path):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)

def aggregate_results_for_model(base_dir, model):
    summary_list = []
    
    model_dir = os.path.join(base_dir, model)
    if not os.path.isdir(model_dir):
        return pd.DataFrame(), pd.DataFrame()

    for crypto in os.listdir(model_dir):
        crypto_dir = os.path.join(model_dir, crypto)
        if not os.path.isdir(crypto_dir):
            continue

        metrics_path = os.path.join(crypto_dir, 'metrics.csv')
        inference_time_path = os.path.join(crypto_dir, 'inference_time.csv')
        train_time_path = os.path.join(crypto_dir, 'train_time.csv')

        if os.path.exists(metrics_path):
            metrics_df = pd.read_csv(metrics_path)
            metrics_df['model'] = model
            metrics_df['crypto'] = crypto

            if os.path.exists(inference_time_path):
                inference_time_df = pd.read_csv(inference_time_path)
                avg_inference_time = inference_time_df.mean().values[0]
                metrics_df['avg_inference_time'] = avg_inference_time

            if os.path.exists(train_time_path):
                train_time_df = pd.read_csv(train_time_path)
                avg_train_time = train_time_df.mean().values[0]
                metrics_df['avg_train_time'] = avg_train_time

            summary_list.append(metrics_df)
        else:
            print(f"Metrics file not found for {crypto} in {model}.")

    if summary_list:
        summary_df = pd.concat(summary_list, ignore_index=True)
        numeric_cols = ['MSE', 'MAE', 'RMSE', 'MAPE', 'R2']
        
        if 'avg_inference_time' in summary_df.columns:
            numeric_cols.append('avg_inference_time')
        if 'avg_train_time' in summary_df.columns:
            numeric_cols.append('avg_train_time')
        
        avg_metrics = summary_df.groupby('crypto')[numeric_cols].mean().reset_index()
        avg_metrics['model'] = model
    else:
        summary_df = pd.DataFrame()
        avg_metrics = pd.DataFrame()
    
    return summary_df, avg_metrics

def main():
    base_directory = '/home/estella/Projects/tsa_crt/results'  # Updated directory to your specified path

    # Ensure the results directory exists
    ensure_dir_exists(base_directory)
    print(f"Searching results in directory {base_directory}")

    all_avg_metrics = []

    for model in os.listdir(base_directory):
        model_dir = os.path.join(base_directory, model)
        if os.path.isdir(model_dir):
            summary_df, avg_metrics = aggregate_results_for_model(base_directory, model)
            if not summary_df.empty:
                summary_path = os.path.join(base_directory, f'summary_{model}.csv')
                summary_df.to_csv(summary_path, index=False)
                print(f"Summary for {model} saved to {summary_path}")

                avg_metrics_path = os.path.join(base_directory, f'avg_metrics_{model}.csv')
                avg_metrics.to_csv(avg_metrics_path, index=False)
                print(f"Average metrics for {model} saved to {avg_metrics_path}")

                all_avg_metrics.append(avg_metrics)
            else:
                print(f"No results to summarize for {model}.")

    if all_avg_metrics:
        all_avg_metrics_df = pd.concat(all_avg_metrics, ignore_index=True)
        all_avg_metrics_path = os.path.join(base_directory, 'all_avg_metrics.csv')
        all_avg_metrics_df.to_csv(all_avg_metrics_path, index=False)
        print(f"All average metrics saved to {all_avg_metrics_path}")

if __name__ == "__main__":
    main()
