import pandas as pd
import matplotlib.pyplot as plt

# Load the summary file
summary_df = pd.read_excel('summary_results.xlsx', sheet_name='Summary')

# Plot comparison of models
plt.figure(figsize=(14, 7))

# Example: Compare MSE across models for BTC
btc_summary = summary_df[summary_df['Crypto'] == 'btc']
models = btc_summary['Model'].unique()
for model in models:
    model_data = btc_summary[btc_summary['Model'] == model]
    plt.plot(model_data['MSE'], label=model)

plt.title('MSE Comparison Across Models for BTC')
plt.xlabel('Time')
plt.ylabel('MSE')
plt.legend()
plt.show()
