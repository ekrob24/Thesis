import numpy as np
import pandas as pd
import os
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, mean_absolute_percentage_error
from keras.models import Sequential
from keras.layers import Dense, LSTM, Dropout, Conv1D
import matplotlib.pyplot as plt
import time


def ensure_dir_exists(dir_path):
    if not dir_path:
        return
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)


def r_squared(true, predicted):
    y = np.array(true)
    y_hat = np.array(predicted)
    y_m = y.mean()
    ss_res = np.sum((y - y_hat) ** 2)
    ss_tot = np.sum((y - y_m) ** 2)
    return 1 - (ss_res / ss_tot)


def save_output_csv(preds_close, preds_volume, labels_close, labels_volume, filename):
    ensure_dir_exists(os.path.dirname(filename))
    df = pd.DataFrame({
        'predicted_close': preds_close.flatten(),
        'predicted_volume': preds_volume.flatten(),
        'actual_close': labels_close.flatten(),
        'actual_volume': labels_volume.flatten(),
    })
    df.to_csv(filename, index=False)


def save_metrics_csv(mses, maes, rmses, mapes, filename, r2):
    ensure_dir_exists(os.path.dirname(filename))
    df = pd.DataFrame({'MSE': mses, 'MAE': maes, 'RMSE': rmses, 'MAPE': mapes, 'R2': r2})
    df.to_csv(filename, index=False)

def save_timing(times, filename):
    ensure_dir_exists(os.path.dirname(filename))
    df_timing = pd.DataFrame(np.asarray(times))
    df_timing.to_csv(filename, index=False)


def plot_loss(history, title):
    plt.figure(figsize=(10, 6))
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('Model Loss')
    plt.ylabel('Loss')
    plt.xlabel('Epoch')
    plt.legend(['Train', 'Test'], loc='upper left')
    plt.savefig(f"results/loss_{title}.png")


def plot_series(series_close, series_close_pred, series_volume, series_volume_pred, title="output"):
    plt.figure(figsize=(12, 8))
    
    plt.subplot(2, 1, 1)
    plt.plot(series_close, label="Actual Close")
    plt.plot(series_close_pred, 'o', label="Predicted Close")
    plt.xlabel("Time")
    plt.ylabel("Price")
    plt.legend()
    plt.grid(True)

    plt.subplot(2, 1, 2)
    plt.plot(series_volume, label="Actual Volume")
    plt.plot(series_volume_pred, 'o', label="Predicted Volume")
    plt.xlabel("Time")
    plt.ylabel("Volume")
    plt.legend()
    plt.grid(True)

    plt.tight_layout()
    plt.savefig(f"results/{title}.png")


class BitcoinDataset:
    def __init__(self, filename="/home/estella/Projects/tsa_crt/saved_data/Bitcoin Historical Data.csv", features=['close', 'volume'], train_split_factor=0.8):
        self.filename = filename
        self.features = features
        self.train_split_factor = train_split_factor
        self.scalers = {feature: MinMaxScaler() for feature in self.features}  

    def load_data(self):
        df = pd.read_csv(self.filename)
        df['date'] = pd.to_datetime(df['date'], format="%d/%m/%Y")
        return df.sort_values('date')

    def dataset_creation(self, df):
        scaled_data = np.zeros(df[self.features].shape)
        for i, feature in enumerate(self.features):
            scaled_data[:, i] = self.scalers[feature].fit_transform(df[feature].values.reshape(-1, 1)).flatten()
        return scaled_data

    def split_data(self, data):
        train_size = int(len(data) * self.train_split_factor)
        train, test = data[:train_size], data[train_size:]
        return train, test

    def create_windows(self, data, look_back=60):
        X, y = [], []
        for i in range(look_back, len(data)):
            X.append(data[i-look_back:i])
            y.append(data[i])  
        X, y = np.array(X), np.array(y)
        return X, y  

    def inverse_transform(self, predicted_data, actual_data):
        predicted = np.zeros(predicted_data.shape)
        actual = np.zeros(actual_data.shape)
        for i, feature in enumerate(self.features):
            predicted[:, i] = self.scalers[feature].inverse_transform(predicted_data[:, i].reshape(-1, 1)).flatten()
            actual[:, i] = self.scalers[feature].inverse_transform(actual_data[:, i].reshape(-1, 1)).flatten()
        return predicted, actual

class LSTMBitcoinModel:
    def __init__(self, experiment_name, look_back=60, params=None, num_features=1):
        self.look_back = look_back
        self.num_features = num_features
        self.model = self.build_model(params)
        self.experiment_name = experiment_name
        self.window_size = params.get('window_size', 1000)
        self.train_time = 0
        self.inference_time = 0

    def build_model(self, params):
        model = Sequential()
        if params.get('first_conv_dim'):
            model.add(Conv1D(filters=params['first_conv_dim'], kernel_size=params['first_conv_kernel'], 
                             activation=params['first_conv_activation'], input_shape=(self.look_back, self.num_features)))
        model.add(LSTM(units=params['first_lstm_dim'], return_sequences=False))
        model.add(Dropout(0.2))
        model.add(Dense(units=params['first_dense_dim'], activation=params['first_dense_activation']))
        model.add(Dense(units=2))
        model.compile(optimizer=params['optimizer'], loss='mean_squared_error')
        return model

    def fit(self, X_train, y_train, epochs=100, batch_size=32):
        start_time = time.time()
        history = self.model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=1, validation_split=0.2)
        self.train_time += time.time() - start_time
        return history

    def predict(self, X):
        start_time = time.time()
        predictions = self.model.predict(X)
        self.inference_time += time.time() - start_time
        return predictions  

    def retrain_model(self, X_train, y_train, epochs=100, batch_size=32):
        for i in range(0, len(X_train) - self.window_size, self.window_size):
            self.model.fit(X_train[i:i+self.window_size], y_train[i:i+self.window_size], 
                           epochs=epochs, batch_size=batch_size, verbose=1)

def run_lstm_with_windowed_retraining(params, retrain_intervals, outputs, scaling):
    mse, rmse, mape, r2_score, mae = [], [], [], [], []
    all_predictions, all_labels, train_time, inference_time = [], [], [], []

    # Load dataset
    dataset = BitcoinDataset()  
    df = dataset.load_data()

    scaled_data = dataset.dataset_creation(df)
    X, y = dataset.create_windows(scaled_data, look_back=params['look_back'])


    X_train, X_test = X[:len(X)-outputs[-1]], X[len(X)-outputs[-1]:]
    y_train, y_test = y[:len(y)-outputs[-1]], y[len(y)-outputs[-1]:]


    lstm_model = LSTMBitcoinModel('bitcoin4_lstm', look_back=params['look_back'], params=params, num_features=len(dataset.features))


    history = lstm_model.fit(X_train, y_train, epochs=params['epochs'], batch_size=params['batch_size'])
    lstm_model.retrain_model(X_train, y_train, epochs=params['epochs'], batch_size=params['batch_size'])


    predicted_prices = lstm_model.predict(X_test)


    predicted_prices, actual_prices = dataset.inverse_transform(predicted_prices, y_test)

    predicted_close = predicted_prices[:, 0]
    predicted_volume = predicted_prices[:, 1]

    actual_close = actual_prices[:, 0]
    actual_volume = actual_prices[:, 1]


    mse.append(mean_squared_error(actual_close, predicted_close))
    mse.append(mean_squared_error(actual_volume, predicted_volume))
    
    rmse.append(np.sqrt(mean_squared_error(actual_close, predicted_close)))
    rmse.append(np.sqrt(mean_squared_error(actual_volume, predicted_volume)))
    
    mae.append(mean_absolute_error(actual_close, predicted_close))
    mae.append(mean_absolute_error(actual_volume, predicted_volume))
    
    mape.append(mean_absolute_percentage_error(actual_close, predicted_close))
    mape.append(mean_absolute_percentage_error(actual_volume, predicted_volume))
    
    r2_score.append(r_squared(actual_close, predicted_close))
    r2_score.append(r_squared(actual_volume, predicted_volume))


    save_output_csv(predicted_close, predicted_volume, actual_close, actual_volume, filename=f"results/bitcoin2_output.csv")
    save_metrics_csv(mse, mae, rmse, mape, filename=f"results/bitcoin4_metrics.csv", r2=r2_score)
    save_timing(train_time, filename=f"results/bitcoin4_train_time.csv")
    save_timing(inference_time, filename=f"results/bitcoin4_inference_time.csv")


    plot_loss(history, 'bitcoin4_lstm')
    plot_series(actual_close, predicted_close, actual_volume, predicted_volume, title='bitcoin4_lstm')

def main():
    retrain_intervals = [0, 30, 31, 31, 30, 31, 30, 31, 31, 28, 31, 30]
    outputs = [30, 31, 31, 30, 31, 30, 31, 31, 28, 31, 30, 31]
    scaling = ['minmax']

    params = {
        'first_conv_dim': 64,
        'first_conv_activation': 'relu',
        'first_conv_kernel': 5,
        'first_lstm_dim': 75,
        'first_dense_dim': 16,
        'first_dense_activation': 'relu',
        'batch_size': 256,
        'epochs': 200,
        'optimizer': 'adam',
        'look_back': 60,
        'window_size': 1000,
        'patience': 50,
        'lr': 1E-4,
        'momentum': 0.9,
        'decay': 1E-3
    }


    run_lstm_with_windowed_retraining(params, retrain_intervals, outputs, scaling)

if __name__ == "__main__":
    main()
