import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential
from keras.layers import Dense, LSTM, Dropout
import matplotlib.pyplot as plt


class LSTMBitcoinModel:
    def __init__(self, look_back=60):
        self.look_back = look_back
        self.scaler = MinMaxScaler(feature_range=(0, 1))
        self.model = self.build_model()

    def build_model(self):
        model = Sequential()
        model.add(LSTM(units=50, return_sequences=True, input_shape=(self.look_back, 1)))
        model.add(Dropout(0.2))
        model.add(LSTM(units=50, return_sequences=False))
        model.add(Dropout(0.2))
        model.add(Dense(units=1))  
        model.compile(optimizer='adam', loss='mean_squared_error')
        return model

    def fit(self, X_train, y_train, epochs=100, batch_size=32):
        print("Training LSTM Model...")
        self.model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size)

    def predict(self, X):
        return self.model.predict(X)

    def preprocess_data(self, df):

        if 'close' not in df.columns:
            raise ValueError("The column 'close' is missing from the dataset.")
        

        df = df[['close']]
        scaled_data = self.scaler.fit_transform(df)

        X, y = [], []
        for i in range(self.look_back, len(scaled_data)):
            X.append(scaled_data[i - self.look_back:i, 0])
            y.append(scaled_data[i, 0])
        X, y = np.array(X), np.array(y)


        X = np.reshape(X, (X.shape[0], X.shape[1], 1))
        return X, y

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)


class BitcoinDataset:
    def __init__(self, filepath):
        self.filepath = filepath
        self.df = self.load_data()

    def load_data(self):
        print(f"Loading dataset from {self.filepath}...")
        df = pd.read_csv(self.filepath, parse_dates=['date'])
        df = df.sort_values('date')
        return df


class SaveResultsBitcoin:
    def __init__(self, predicted_prices, actual_prices):
        self.predicted_prices = predicted_prices
        self.actual_prices = actual_prices

    def save_to_csv(self, filename):
        print(f"Saving results to {filename}...")
        results_df = pd.DataFrame({
            'Actual': self.actual_prices.flatten(),
            'Predicted': self.predicted_prices.flatten()
        })
        results_df.to_csv(filename, index=False)


def run_bitcoin_price_prediction(data_path):

    dataset = BitcoinDataset(data_path)
    df = dataset.df


    lstm_model = LSTMBitcoinModel(look_back=60)


    X, y = lstm_model.preprocess_data(df)


    split = int(len(X) * 0.8)
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]


    print(f"Shape of X_train: {X_train.shape}")
    print(f"Shape of y_train: {y_train.shape}")
    print(f"Shape of X_test: {X_test.shape}")
    print(f"Shape of y_test: {y_test.shape}")


    lstm_model.fit(X_train, y_train, epochs=100, batch_size=32)


    predicted_prices = lstm_model.predict(X_test)

    predicted_prices = lstm_model.inverse_transform(predicted_prices)
    actual_prices = lstm_model.inverse_transform(y_test.reshape(-1, 1))


    plt.plot(actual_prices, color='red', label='Actual Bitcoin Price')
    plt.plot(predicted_prices, color='blue', label='Predicted Bitcoin Price')
    plt.title('Bitcoin Price Prediction')
    plt.xlabel('Time')
    plt.ylabel('Price')
    plt.legend()
    plt.show()


    save_results = SaveResultsBitcoin(predicted_prices, actual_prices)
    save_results.save_to_csv('bitcoin_price_predictions.csv')

if __name__ == "__main__":

    run_bitcoin_price_prediction('/home/estella/Projects/tsa_crt/saved_data/Bitcoin Historical Data.csv')
