import tensorflow as tf
from tensorflow.keras.layers import Input, Dense, Concatenate, Flatten
from tensorflow.keras.optimizers import Adam, RMSprop, Nadam, SGD
from tensorflow.keras.utils import plot_model  
import pandas as pd
from models.dl.model_interface_dl import ModelInterfaceDL
import os  

class chyB4(ModelInterfaceDL):
    def __init__(self, name):
        super().__init__(name)
        

        self.history = {'epoch': [], 'train_loss': [], 'val_loss': []}

 
        if tf.config.list_physical_devices('GPU'):
            print("Using GPU for training.")
            self.parameter_list = {
                "accelerator": "gpu",
                "devices": -1,
                'first_dense_dim': [32, 64, 128],
                'first_dense_activation': ['relu', 'tanh', 'selu'],
                'second_dense_dim': [16, 32, 64],
                'second_dense_activation': ['relu', 'elu', 'selu', 'tanh'],
                'context_units': [10, 20, 30],
                'batch_size': [256, 512, 1024],
                'epochs': [200],
                'patience': [50],
                'optimizer': ['adam', 'nadam', 'rmsprop'],
                'lr': [1E-3, 1E-4, 1E-5],
                'momentum': [0.9, 0.99],
                'decay': [1E-3, 1E-4, 1E-5],
            }
        else:
            print("Using CPU for training.")
            self.parameter_list = {
                "accelerator": "cpu",
                'first_dense_dim': [32, 64, 128],
                'first_dense_activation': ['relu', 'tanh', 'selu'],
                'second_dense_dim': [16, 32, 64],
                'second_dense_activation': ['relu', 'elu', 'selu', 'tanh'],
                'context_units': [10, 20, 30],
                'batch_size': [256, 512, 1024],
                'epochs': [200],
                'patience': [50],
                'optimizer': ['adam', 'nadam', 'rmsprop'],
                'lr': [1E-3, 1E-4, 1E-5],
                'momentum': [0.9, 0.99],
                'decay': [1E-3, 1E-4, 1E-5],
            }

        # Default parameters
        self.p = {
            'first_dense_dim': 64,
            'first_dense_activation': 'selu',
            'second_dense_dim': 16,
            'second_dense_activation': 'tanh',
            'context_units': 20,
            'batch_size': 512,
            'epochs': 200,
            'patience': 50,
            'optimizer': 'nadam',
            'lr': 1E-5,
            'momentum': 0.99,
            'decay': 1E-3,
        }

    def create_model(self):
        input_shape = self.ds.X_train.shape[1:]  


        main_input_shape = (input_shape[0] - self.p['context_units'], input_shape[1])

   
        input_layer = Input(shape=main_input_shape)
        context_input = Input(shape=(self.p['context_units'],))

        # First dense layer
        dense_1 = Dense(self.p['first_dense_dim'], activation=self.p['first_dense_activation'])(input_layer)

    
        dense_1_flat = Flatten()(dense_1)

     
        combined_input = Concatenate()([dense_1_flat, context_input])

        # Second dense layer
        dense_2 = Dense(self.p['second_dense_dim'], activation=self.p['second_dense_activation'])(combined_input)


        output = Dense(1)(dense_2)


        self.temp_model = tf.keras.models.Model(inputs=[input_layer, context_input], outputs=output)


        output_dir = '/home/estella/Projects/tsa_crt/history'
        os.makedirs(output_dir, exist_ok=True) 


        plot_model(self.temp_model, to_file=f'{output_dir}/{self.name}_architecture.png', show_shapes=True, show_layer_names=False)
        print(f"Model architecture plot saved as {output_dir}/{self.name}_architecture.png")

        if self.p['optimizer'] == 'adam':
            opt = Adam(learning_rate=self.p['lr'])
        elif self.p['optimizer'] == 'rmsprop':
            opt = RMSprop(learning_rate=self.p['lr'])
        elif self.p['optimizer'] == 'nadam':
            opt = Nadam(learning_rate=self.p['lr'])
        elif self.p['optimizer'] == 'sgd':
            opt = SGD(learning_rate=self.p['lr'], momentum=self.p['momentum'])

        self.temp_model.compile(loss='mean_squared_error',
                                optimizer=opt,
                                metrics=["mse", "mae"])

    def fit(self):
        self.create_model()

     
        context_units = self.p['context_units']
        

        main_input_shape = self.ds.X_train.shape[1] - context_units
        if main_input_shape <= 0:
            raise ValueError(f"Context units ({context_units}) exceed or equal input dimensions ({self.ds.X_train.shape[1]}).")

        main_input = self.ds.X_train[:, :main_input_shape, :]
        context_input = self.ds.X_train[:, -context_units:, 0]

        print(f"Main input shape: {main_input.shape}")
        print(f"Context input shape: {context_input.shape}")


        history = self.temp_model.fit(
            [main_input, context_input], 
            self.ds.y_train,
            epochs=self.p['epochs'],
            batch_size=self.p['batch_size'],
            validation_split=0.2,
            callbacks=[tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=self.p['patience'])],
            verbose=1
        )
        
    
        for epoch, train_loss, val_loss in zip(range(1, len(history.history['loss']) + 1),
                                               history.history['loss'],
                                               history.history['val_loss']):
            self.history['epoch'].append(epoch)
            self.history['train_loss'].append(train_loss)
            self.history['val_loss'].append(val_loss)
        
        return history, self.temp_model

    def predict(self, X):
 
        main_input = X[:, :-self.p['context_units'], :]
        context_input = X[:, -self.p['context_units']:, 0]

        predictions = self.temp_model.predict([main_input, context_input])
        return predictions

    def save_history(self, filename):
        """
        Save the training history to a CSV file.
        """
        df_history = pd.DataFrame(self.history)
        df_history.to_csv(filename, index=False)
        print(f"Training history saved to {filename}")
