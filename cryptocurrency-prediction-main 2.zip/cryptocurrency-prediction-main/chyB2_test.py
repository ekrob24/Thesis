import os
import numpy as np
import pandas as pd
from models.dl.chyB2 import chyB2
from util import save_results, dataset_binance, r2
from sklearn.metrics import mean_squared_error, mean_absolute_error, mean_absolute_percentage_error

def main():
    h = 0  
    targets = ['close']
    cryptos = ['btc', 'eth', 'ltc', 'xmr', 'xrp']
    retrain = [0, 30, 31, 31, 30, 31, 30, 31, 31, 28, 31, 30]
    outputs = [30, 31, 31, 30, 31, 30, 31, 31, 28, 31, 30, 31]
    scaling = ['minmax']
    tuned = 0
    window = 30

    for t in targets:
        for c in cryptos:
            add_split_value = 0
            mse, rmse, mape, r2_score, mae = [], [], [], [], []
            all_predictions, all_labels, train_time, inference_time = [], [], [], []
            for index, r in enumerate(retrain):
                output = outputs[index]

                experiment_name = f'chyB2-{c}-{t}-w{window}-h{h}-{len(outputs)}m'
                ds = dataset_binance.BinanceDataset(
                    filename=f'crypto_task_{c}.csv', input_window=window, output_window=1,
                    horizon=h, training_features=['close'],
                    target_name=['close'], train_split_factor=0.8
                )

                df, diff_df = ds.differenced_dataset()
                ds.df = diff_df

                if index > 0:
                    add_split_value += r
                ds.add_split_value = add_split_value

                if tuned:
                    parameters = pd.read_csv(f"param/p_chyB2-{t}-{c}-w{window}-h{h}.csv").iloc[0]
                    p = {
                        'input_chunk_length': parameters['input_chunk_length'],
                        'hidden_layer_dim': parameters['hidden_layer_dim'],
                        'num_lstm_layers': parameters['num_lstm_layers'],
                        'dropout_rate': parameters['dropout_rate'],
                        'batch_size': parameters['batch_size'],
                        'output_chunk_length': parameters['output_chunk_length'],
                        'patience': parameters['patience'],
                        'lr': parameters['lr'],
                        'optimizer': parameters['optimizer'],
                        'epochs': parameters['epochs'],
                    }
                else:
                    p = {
                        'input_chunk_length': 30,
                        'hidden_layer_dim': 64,
                        'num_lstm_layers': 3,
                        'dropout_rate': 0.05,
                        'batch_size': 256,
                        'output_chunk_length': 1,
                        'patience': 50,
                        'lr': 1e-3,
                        'optimizer': 'adam',
                        'epochs': 200,
                    }

                # Initialize the chyB2 model
                model = chyB2(experiment_name)
                model.ds = ds
                ds.dataset_creation(df=True, detrended=True)
                ds.dataset_normalization(scaling)
                ds.data_summary()

                to_predict = ds.X_test[:output]

                # Train the model
                model.create_model()
                trained_model, _ = model.fit()

                # Make predictions
                yhat = model.predict(to_predict)

                # Reshape predictions if necessary
                preds = yhat.reshape(-1, 1)

                # Inverse transformations
                np_preds = ds.inverse_transform_predictions(preds=preds)
                inversed_preds = ds.inverse_differenced_dataset(diff_vals=np_preds, df=df, l=len(ds.y_test_array))

                ds.df = df
                ds.dataset_creation(df=True)
                labels = ds.y_test_array[h:len(inversed_preds) + h].reshape(-1, 1)
                ds.dataset_normalization(scaling)

                n_preds = ds.scale_predictions(preds=inversed_preds)
                n_labels = ds.scale_predictions(preds=labels)

                # Collect metrics
                mse.append(mean_squared_error(n_labels, n_preds))
                rmse.append(np.sqrt(mean_squared_error(n_labels, n_preds)))
                mae.append(mean_absolute_error(n_labels, n_preds))
                mape.append(mean_absolute_percentage_error(n_labels, n_preds))
                r2_score.append(r2.r_squared(n_labels, n_preds))

                print(f"MSE: {mse[-1]:.4f}, MAE: {mae[-1]:.4f}, MAPE: {mape[-1]:.4f}, RMSE: {rmse[-1]:.4f}, R2: {r2_score[-1]:.4f}")

                all_predictions.extend(n_preds)
                all_labels.extend(n_labels)
                train_time.append(model.train_time)
                inference_time.append(model.inference_time)

            # Save the history for the model
            history_filename = f"history/{experiment_name}_history.csv"
            model.save_history(history_filename)

            if not tuned:
                save_results.save_params_csv(model.p, model.name)

            # Save predictions and metrics
            save_results.save_output_csv(preds=all_predictions, labels=all_labels, feature=t, filename=experiment_name, bivariate=len(ds.target_name) > 1)
            save_results.save_metrics_csv(mses=mse, maes=mae, rmses=rmse, mapes=mape, filename=experiment_name, r2=r2_score)
            save_results.save_timing(times=inference_time, filename=f"{experiment_name}-inf_time")
            save_results.save_timing(times=train_time, filename=f"{experiment_name}-train_time")

if __name__ == "__main__":
    main()
